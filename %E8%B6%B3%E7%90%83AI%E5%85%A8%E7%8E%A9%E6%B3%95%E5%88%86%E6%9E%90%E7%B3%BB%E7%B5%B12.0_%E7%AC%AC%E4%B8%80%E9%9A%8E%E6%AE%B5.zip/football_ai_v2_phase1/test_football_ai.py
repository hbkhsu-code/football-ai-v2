import unittest
from football_ai import poisson_pmf, score_matrix, summarize_matrix, analyze_match

class TestFootballAI(unittest.TestCase):
    def test_poisson_zero(self):
        self.assertEqual(poisson_pmf(0, 0), 1.0)
        self.assertEqual(poisson_pmf(1, 0), 0.0)

    def test_matrix_shape(self):
        m = score_matrix(1.2, 0.8, 6)
        self.assertEqual(len(m), 7)
        self.assertEqual(len(m[0]), 7)

    def test_market_probabilities_bounded(self):
        s = summarize_matrix(score_matrix(1.5, 1.0, 10))
        for value in s.values():
            self.assertGreaterEqual(value, 0.0)
            self.assertLessEqual(value, 1.000001)

    def test_analysis_top10(self):
        r = analyze_match("A", "B", 1.6, 0.9, trials=1000)
        self.assertEqual(len(r["比分前10名"]), 10)
        self.assertEqual(r["蒙地卡羅"]["模擬次數"], 1000)

if __name__ == "__main__":
    unittest.main()
