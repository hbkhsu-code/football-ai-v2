# 足球 AI 全玩法分析系統 2.0 — 第一階段

## 目標
建立可在 iPhone Safari / GitHub Codespaces 使用的 Python 核心引擎。第一階段先完成比分機率矩陣、前10名比分、勝平負、大小球、BTTS 與蒙地卡羅模擬。

## 重要限制
- 目前採獨立 Poisson 基礎模型，尚未加入 Dixon-Coles、Elo、xG/xGA、傷停、先發、即時賽程或台灣運彩盤口。
- `lambda_home` 與 `lambda_away` 是使用者輸入的預期進球參數。不得把示範值當成真實球隊預測。
- 半場預測暫以全場 lambda 的 45% 粗略近似，未經歷史資料校準。
- 比分矩陣列舉 0 至 max_goals，保留並顯示矩陣涵蓋機率，避免把尾端遺漏誤當作總機率 100%。
- 模擬結果是模型假設下的抽樣，不會讓模型自動變準，也不代表保證中獎。
- 投注前必須另行核對台灣運彩官方實際玩法、盤口、賠率及停售狀態。

## 在 iPhone 使用 GitHub Codespaces
1. 用 Safari 開啟 GitHub 並登入。
2. 建立新 Repository，例如 `football-ai-v2`。
3. 將本資料夾內 `football_ai.py`、`matches_template.csv`、`README.md` 上傳到 Repository。
4. 在 Repository 點選 `Code` → `Codespaces` → `Create codespace on main`。
5. 等待 VS Code 網頁版開啟。
6. 開啟 Terminal，執行下方指令。

## 執行單場示範
```bash
python football_ai.py --home "主隊示範" --away "客隊示範" --lambda-home 1.8 --lambda-away 0.9 --trials 10000 --out demo.json
```
以上 lambda 僅為程式測試示範，不是任何真實比賽預測。

## 批次 CSV
```bash
python football_ai.py --csv matches_template.csv --trials 10000 --out batch_results.json
```

CSV 欄位：
- `home`：主隊
- `away`：客隊
- `lambda_home`：主隊預期進球
- `lambda_away`：客隊預期進球

## 第一階段輸出
- 前10名比分機率
- 主勝／和局／客勝
- 大小球 1.5、2.5、3.5
- BTTS 是／否
- 高比分觀察
- 公平賠率（僅為模型機率倒數，非莊家報價）
- 半場粗略勝平負
- Monte Carlo 模擬結果

## 開發路線
1. 第一階段：Poisson 比分引擎（目前）
2. 第二階段：資料匯入與特徵工程（賽程、近期戰績、主客場、xG/xGA）
3. 第三階段：Dixon-Coles、Elo、貝葉斯與機率集成
4. 第四階段：半全場、角球、讓分、BTTS 完整玩法
5. 第五階段：台灣運彩盤口／賠率匯入與價值分析
6. 第六階段：跨場跨玩法串五最佳化與相關性控制
7. 第七階段：時間序列回測、Brier Score、Log Loss、ROI、校準曲線
8. 第八階段：iPhone 友善 Streamlit 或輕量網頁介面

## 免費優先原則
先使用 Python 標準函式庫，不依賴付費 API。資料來源需遵守網站條款及資料授權；不可假設所有網站都提供免費 API。
