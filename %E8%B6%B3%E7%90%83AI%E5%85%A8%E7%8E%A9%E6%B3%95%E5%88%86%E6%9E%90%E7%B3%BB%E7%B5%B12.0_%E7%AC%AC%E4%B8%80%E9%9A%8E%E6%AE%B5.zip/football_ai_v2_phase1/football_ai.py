#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
足球 AI 全玩法分析系統 2.0 - 第一階段
核心：獨立 Poisson 進球模型 + 比分矩陣 + 市場機率 + Monte Carlo
注意：lambda_home / lambda_away 必須由使用者或後續資料模型提供；
本程式不會自行假裝取得即時球隊資料、傷停或台灣運彩盤口。
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any


def poisson_pmf(k: int, lam: float) -> float:
    if k < 0:
        return 0.0
    if lam < 0:
        raise ValueError("預期進球 lambda 不可小於 0")
    if lam == 0:
        return 1.0 if k == 0 else 0.0
    return math.exp(-lam + k * math.log(lam) - math.lgamma(k + 1))


def poisson_cdf_upto(max_goals: int, lam: float) -> list[float]:
    """回傳 0..max_goals 的 PMF；保留未涵蓋尾端機率，不強制重新正規化。"""
    return [poisson_pmf(k, lam) for k in range(max_goals + 1)]


def score_matrix(lh: float, la: float, max_goals: int = 10) -> list[list[float]]:
    hp = poisson_cdf_upto(max_goals, lh)
    ap = poisson_cdf_upto(max_goals, la)
    return [[h * a for a in ap] for h in hp]


def summarize_matrix(matrix: list[list[float]]) -> dict[str, float]:
    home = draw = away = over_15 = over_25 = over_35 = btts_yes = 0.0
    under_15 = under_25 = under_35 = btts_no = 0.0
    for h, row in enumerate(matrix):
        for a, p in enumerate(row):
            if h > a:
                home += p
            elif h == a:
                draw += p
            else:
                away += p
            total = h + a
            if total >= 2: over_15 += p
            else: under_15 += p
            if total >= 3: over_25 += p
            else: under_25 += p
            if total >= 4: over_35 += p
            else: under_35 += p
            if h > 0 and a > 0: btts_yes += p
            else: btts_no += p
    return {
        "主勝": home, "和局": draw, "客勝": away,
        "大1.5": over_15, "小1.5": under_15,
        "大2.5": over_25, "小2.5": under_25,
        "大3.5": over_35, "小3.5": under_35,
        "BTTS是": btts_yes, "BTTS否": btts_no,
        "矩陣涵蓋機率": sum(map(sum, matrix)),
    }


def top_scores(matrix: list[list[float]], n: int = 10) -> list[dict[str, Any]]:
    rows = []
    for h, row in enumerate(matrix):
        for a, p in enumerate(row):
            rows.append({"比分": f"{h}:{a}", "主隊進球": h, "客隊進球": a, "機率": p})
    return sorted(rows, key=lambda x: x["機率"], reverse=True)[:n]


def monte_carlo(lh: float, la: float, trials: int = 10_000, seed: int = 539) -> dict[str, Any]:
    rng = random.Random(seed)
    outcomes = {"主勝": 0, "和局": 0, "客勝": 0}
    totals = {">=2球": 0, ">=3球": 0, ">=4球": 0}
    btts = 0
    scores: dict[tuple[int, int], int] = {}
    for _ in range(trials):
        h = rng.poisson(lh) if hasattr(rng, "poisson") else _sample_poisson(rng, lh)
        a = _sample_poisson(rng, la)
        if h > a: outcomes["主勝"] += 1
        elif h == a: outcomes["和局"] += 1
        else: outcomes["客勝"] += 1
        total = h + a
        if total >= 2: totals[">=2球"] += 1
        if total >= 3: totals[">=3球"] += 1
        if total >= 4: totals[">=4球"] += 1
        if h > 0 and a > 0: btts += 1
        scores[(h, a)] = scores.get((h, a), 0) + 1
    return {
        "模擬次數": trials,
        "隨機種子": seed,
        "勝平負": {k: v / trials for k, v in outcomes.items()},
        "大小球": {k: v / trials for k, v in totals.items()},
        "BTTS是": btts / trials,
        "模擬前10比分": [
            {"比分": f"{h}:{a}", "機率": count / trials}
            for (h, a), count in sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:10]
        ],
    }


def _sample_poisson(rng: random.Random, lam: float) -> int:
    """Knuth algorithm; appropriate for football scoring rates."""
    if lam < 0:
        raise ValueError("lambda 不可小於 0")
    if lam == 0:
        return 0
    limit = math.exp(-lam)
    k = 0
    product = 1.0
    while product > limit:
        k += 1
        product *= rng.random()
    return k - 1


def fair_odds(probability: float) -> float | None:
    return (1.0 / probability) if probability > 0 else None


def analyze_match(
    home: str, away: str, lh: float, la: float,
    max_goals: int = 10, trials: int = 10_000, seed: int = 539
) -> dict[str, Any]:
    if not (0 <= lh <= 8 and 0 <= la <= 8):
        raise ValueError("第一版 lambda 請設定在 0～8 之間，超出請先檢查輸入")
    matrix = score_matrix(lh, la, max_goals)
    markets = summarize_matrix(matrix)
    scores = top_scores(matrix, 10)
    # 半場先以全場預期進球的45%作粗略近似；不是已校準的半場模型。
    ht_matrix = score_matrix(lh * 0.45, la * 0.45, max_goals)
    ht = summarize_matrix(ht_matrix)
    result = {
        "系統": "足球 AI 全玩法分析系統 2.0 - 第一階段",
        "模型": "獨立 Poisson（基礎版，尚未加入 Dixon-Coles 修正）",
        "主隊": home,
        "客隊": away,
        "輸入預期進球": {"主隊_lambda": lh, "客隊_lambda": la},
        "說明": [
            "lambda 是輸入值，不代表已從即時資料估算。",
            "比分矩陣只列出 0 至 max_goals，極小尾端機率可能未納入。",
            "半場分析暫以全場 lambda 的45%近似，需後續以歷史半場資料校準。",
            "模型機率不是保證命中率；投注前須核對台灣運彩實際玩法及賠率。"
        ],
        "比分前10名": scores,
        "高比分觀察": [x for x in scores if x["主隊進球"] >= 3 and x["客隊進球"] == 0],
        "玩法機率": markets,
        "玩法公平賠率": {k: fair_odds(v) for k, v in markets.items() if k != "矩陣涵蓋機率"},
        "半場粗略勝平負": {k: ht[k] for k in ("主勝", "和局", "客勝")},
        "蒙地卡羅": monte_carlo(lh, la, trials, seed),
    }
    return result


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        required = {"home", "away", "lambda_home", "lambda_away"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("CSV 必須包含欄位：home, away, lambda_home, lambda_away")
        return list(reader)


def main() -> None:
    parser = argparse.ArgumentParser(description="足球比分與全玩法機率分析（第一階段）")
    parser.add_argument("--home", help="主隊名稱")
    parser.add_argument("--away", help="客隊名稱")
    parser.add_argument("--lambda-home", type=float, help="主隊預期進球")
    parser.add_argument("--lambda-away", type=float, help="客隊預期進球")
    parser.add_argument("--trials", type=int, default=10_000, help="蒙地卡羅次數，預設10000")
    parser.add_argument("--max-goals", type=int, default=10, help="比分矩陣每隊最大列舉進球")
    parser.add_argument("--seed", type=int, default=539, help="固定隨機種子，便於重現")
    parser.add_argument("--csv", type=Path, help="批次輸入 CSV")
    parser.add_argument("--out", type=Path, default=Path("analysis_result.json"), help="JSON輸出檔")
    args = parser.parse_args()

    if args.csv:
        matches = load_csv(args.csv)
        results = []
        for m in matches:
            results.append(analyze_match(
                m["home"], m["away"], float(m["lambda_home"]), float(m["lambda_away"]),
                args.max_goals, args.trials, args.seed
            ))
    else:
        if not all([args.home, args.away]) or args.lambda_home is None or args.lambda_away is None:
            parser.error("單場模式需提供 --home、--away、--lambda-home、--lambda-away；或使用 --csv")
        results = [analyze_match(args.home, args.away, args.lambda_home, args.lambda_away,
                                 args.max_goals, args.trials, args.seed)]

    payload = results if args.csv else results[0]
    args.out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    print(f"\n分析結果已輸出：{args.out}")


if __name__ == "__main__":
    main()
